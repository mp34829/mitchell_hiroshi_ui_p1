const state = {
    authUser: null
}

export default state;