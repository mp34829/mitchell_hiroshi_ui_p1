const APP_ROOT = document.getElementById('app-root');

export default {
    rootDiv: APP_ROOT,
    apiUrl: 'http://bookstoreapi-env.eba-ysp2j7xq.us-east-1.elasticbeanstalk.com'
}